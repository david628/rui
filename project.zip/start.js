const path = require(`path`);
const open = require(`open`);
const webpack = require(`webpack`);
const express = require(`express`);
const webpackDevMiddleware = require(`webpack-dev-middleware`);
const webpackHotMiddleware = require(`webpack-hot-middleware`);
const config = require(`./webpack.config.dev`);
const app = express();
const compiler = webpack(config);
app.use(webpackDevMiddleware(compiler, {
	publicPath: `/`,
	contentBase: path.join(__dirname, `/dist`),
	stats: {
		colors: true
	},
	inline: true,
	hot: true,
	compress: true,
	clientLogLevel: `info`,
	filename: path.join(__dirname, `./index.html`)
}));
app.use(webpackHotMiddleware(compiler, {
	log: console.log,
	path: `/__webpack_hmr`,
	heartbeat: 10 * 1000
}));
//app.use(express.static(`dist`));
app.listen(8000, function() {
	console.log(`Listening on port 8000...`);
	open(`http://localhost:8000/index.html`);
});