const webpack = require(`webpack`);
const config = require(`./webpack.config.build`);
const compiler = webpack(config);
compiler.run(function(err, stats) {
	if(err) {
		console.error(err.stack || err);
		if(err.details) {
			console.error(err.details);
		}
		process.exit(1);
		return;
	}
	const info = stats.toJson({timings: true});
	if(stats.hasErrors()) {
		console.error(info.errors);
	}
	if(stats.hasErrors()) {
		console.warn(info.warnning);
	}
	console.log(stats.toString({
		chunks: false,
		colors: true
	}));
});