define([], function () {
    return [{
    	state: '/home', 
    	templateUrl: 'business/controllers/home/home.html',
    	controller: 'business/controllers/home/homeCtrl'
    }, {
    	state: '/a', 
    	templateUrl: 'business/controllers/a/a.html',
    	controller: 'business/controllers/a/aCtrl'
    }, {
    	state: '/b', 
    	templateUrl: 'business/controllers/b/b.html',
    	controller: 'business/controllers/b/bCtrl'
    }, {
    	state: '/c', 
    	templateUrl: 'business/controllers/c/c.html',
    	controller: 'business/controllers/c/cCtrl'
    }, {
    	state: "/d", 
    	templateUrl: 'business/controllers/d/d.html',
    	controller: 'business/controllers/d/dCtrl'
    }, {
        state: '/e', 
        templateUrl: 'business/controllers/e/e.html',
        controller: 'business/controllers/e/eCtrl'
    }];
});
