define(['app'], function(app) {
	app.register.controller('cCtrl',function($scope, $state) {
		$scope.str = 'c page';
	});
})