define(['app'], function(app) {
	app.register.controller('dCtrl',function($scope, $state) {
		$scope.str = 'd page';
	});
})