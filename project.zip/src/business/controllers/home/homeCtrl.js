define(['app'], function(app) {
	app.register.controller('homeCtrl', function($scope, $state) {
		$scope.str = 'home page';
	});
})