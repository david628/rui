define(['app'], function(app) {
	app.register.controller('eCtrl',function($scope, $state) {
		$scope.str = 'e page';
	});
})