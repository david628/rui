define(['app'], function(app) {
	app.register.controller('aCtrl',function($scope, $state) {
		$scope.str = 'a page';
	});
})