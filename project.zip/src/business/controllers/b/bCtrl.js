define(['app'], function(app) {
	app.register.controller('bCtrl',function($scope, $state) {
		$scope.str = 'b page';
	});
})