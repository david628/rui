//import 'script-loader!./lib/require.js';
//import 'script-loader!./main.js';
require(['app'], function() {
	angular.bootstrap(document.body, ['ngApp'])
});
