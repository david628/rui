require.config({
	baseUrl: 'src',
	paths: {
		'app': 'app',
		'angular': './lib/angular',
		'router': './lib/angular-ui-router'
	},
	shim: {
		'angular': {
			exports: 'angular'
		},
		'router': {
			deps: ['angular']
		},
		'app': {
			deps: ['router']
		}
	}
})
require(['app'], function() {
	angular.bootstrap(document.body, ['ngApp'])
})
