const path = require('path');
const webpack = require('webpack');
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const HtmlWebpackPlugin = require('html-webpack-plugin');
const CopyWebpackPlugin = require('copy-webpack-plugin');

// Is the current build a development build
const IS_DEV = (process.env.NODE_ENV === 'development');

const dirNode = 'node_modules';
const dirApp = path.join(__dirname, './src');
const dirAssets = path.join(__dirname, './src/assets');
const indexHTML = path.join(__dirname, 'index.html');

const appHtmlTitle = 'Data';
/**
 * Webpack Configuration
 */
module.exports = {
  //mode: process.env.NODE_ENV,
  entry: {
    //vendor: ['lodash'],
    index: path.join(dirApp, 'index')
  },
  resolve: {
    // alias: {
    //   'app': path.join(__dirname, './src/lib/app'),
    //   'angular': path.join(__dirname, './src/lib/angular'),
    //   'router': path.join(__dirname, './src/lib/angular-ui-router')
    // },
    modules: [
      dirNode,
      dirApp,
      dirAssets
    ]
  },
  plugins: [
    /*new webpack.ProvidePlugin({
        "$": "jquery",
        "jQuery": "jquery",
        "window.jQuery": "jquery"
    }),*/
    new CopyWebpackPlugin([{
      from: './src/lib', to: './lib'
    }]),
    new webpack.DefinePlugin({
      IS_DEV: IS_DEV
    }),
    new MiniCssExtractPlugin({
      // Options similar to the same options in webpackOptions.output
      // both options are optional
      filename: "static/css/[name].[contenthash].css",
      chunkFilename: "static/css/[id].css"
    }),
    new HtmlWebpackPlugin({
      //favicon: './src/assets/images/favicon.ico',
      template: indexHTML,
      //title: appHtmlTitle,
      chunks: ['common', 'index'],
      filename: "index.html"
    })
  ],
  optimization: {
    splitChunks: {
      cacheGroups: {
        vendor: {
          test: /[\\/]node_modules[\\/]/,
          name: 'common',
          priority: 10,
          chunks: 'all'
        }
      }
    }
  },
  module: {
    rules: [
    // { test: /app/, loader: 'expose-loader?app!import-loader?router' },
    // { test: /router/, loader: 'expose-loader?router!import-loader?angular' },
    // { test: /angular/, loader: 'exports-loader?angular' },
    {
      test: /\.js$/,
      loader: 'babel-loader',
      exclude: /(node_modules)/,
      options: {
        compact: true
      }
    }, {
      test: /\.html$/,
        loader: "html-loader"
    }, {
      test: /\.css$/,
      use: [
        'style-loader',
        {
          loader: 'css-loader',
          options: {
            sourceMap: IS_DEV
          }
        }
      ]
    }, {
      test: /\.(scss|less)$/,
      use: [
        'style-loader',
        MiniCssExtractPlugin.loader,
        {
          loader: 'css-loader',
          options: {
            sourceMap: IS_DEV
          }
        }/*, {
          loader: 'sass-loader',
          options: {
            sourceMap: IS_DEV,
            includePaths: [dirAssets]
          }
        }*/, {  
          loader: 'less-loader',
          options: {
            sourceMap: IS_DEV,
            includePaths: [dirAssets],
            javascriptEnabled: true
          }
        }
      ]
    }, {
      test: /\.(jpe?g|png|gif|cur)$/,
      loader: 'file-loader',
      options: {
        name: '[path][name].[ext]',
        publicPath: '../../'
      }
    }/*, {
      test: /\.txt$/,
      use: 'raw-loader'
    }*/]
  }
};
