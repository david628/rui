const path = require('path');
const merge = require('webpack-merge');
const webpackConfig = require('./webpack.config');

module.exports = merge(webpackConfig, {
  devtool: 'source-map',
  mode: "development",
  output: {
    //pathinfo: true,
    publicPath: '/',
    filename: '[name].js'
    // path: path.join(__dirname, './build'),
    // filename: '[name].js',
    // library: 'app',
    // libraryTarget: 'umd',
    // umdNamedDefine: true
  }
});
